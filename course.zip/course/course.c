/**
 * @file course.c
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Appends a students name to the courses list of students. Initializes the course's student list if it doesn't exist yet by using Calloc. If the student list does exist, makes it larger using Realloc.
 * 
 * @param course
 * @param student
 */ 
void enroll_student(Course *course, Student *student)
{
  course->total_students++; //Adds one student to the total student count
  if (course->total_students == 1) // If the student added is the first student, creates space for the student.
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = // If the the student isnt the first student, adds space for the student to the previously allocated space for students.
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Outputs the course information, which is the Name, Course Code, Number of Students, and all the Students. 
 * 
 * @param course
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) // A loop to print out every student in the class
    print_student(&course->students[i]);
}

/**
 * @brief Returns the best performing student in course, determined by the students average.
 * 
 * @param course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) // Checks every students average in a loop
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) //If the current students average is higher than the previously established highest average, they become the top student
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student; // Returns the top student
}

/**
 * @brief Returns a list of the students who are passing the course. A pass is defined by having an average greater than or equal to 50.
 * 
 * @param course
 * @param total_passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; //Checks how many students are passing
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50) // Adds all the passing students to a list
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}